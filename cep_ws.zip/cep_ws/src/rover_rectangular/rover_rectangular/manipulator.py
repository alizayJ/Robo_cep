#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Float64
import time

class ManipulatorControlNode(Node):
    def __init__(self):
        super().__init__('manipulator_node')
        
        # Two separate publishers for the two joints
        self.pub_j1 = self.create_publisher(Float64, '/model/manipulator/joint/joint_1/cmd_pos', 10)
        self.pub_j2 = self.create_publisher(Float64, '/model/manipulator/joint/joint_2/cmd_pos', 10)

        self.subscription = self.create_subscription(LaserScan, '/scan', self.sensor_callback, 10)

        self.is_moving = False
        self.get_logger().info('Manipulator Node Online')

        # Initial Pose: J1=0, J2=90 degrees (1.57 rad)
        self.create_timer(2.0, self.set_initial_pose)

    def send_pos(self, j1, j2):
        m1, m2 = Float64(), Float64()
        m1.data, m2.data = float(j1), float(j2)
        self.pub_j1.publish(m1)
        self.pub_j2.publish(m2)

    def set_initial_pose(self):
        if not self.is_moving:
            self.send_pos(0.0, 1.57)

    def sensor_callback(self, msg):
        valid_ranges = [r for r in msg.ranges if r > 0.06 and r < msg.range_max]
        if not valid_ranges: return
        
        min_dist = min(valid_ranges)
        if min_dist < 0.2 and not self.is_moving:
            self.get_logger().warn(f'Object detected at {min_dist:.2f}m!')
            self.execute_sequence()

    def execute_sequence(self):
        self.is_moving = True
        self.send_pos(1.57, 1.57) # Detection: J1 to 90, J2 stays at 90
        time.sleep(2.0)
        self.send_pos(0.0, 1.57)  # Return to start
        time.sleep(1.0)
        self.is_moving = False

def main(args=None):
    rclpy.init(args=args)
    rclpy.spin(ManipulatorControlNode())
    rclpy.shutdown()

if __name__ == '__main__':
    main()