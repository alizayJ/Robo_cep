import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
import xacro

def generate_launch_description():
    pkg_description = get_package_share_directory('robot_description')
    pkg_ros_gz_sim = get_package_share_directory('ros_gz_sim')

    # 1. Process Xacros (Ensure both files have their macros defined inside!)
    rover_xml = xacro.process_file(os.path.join(pkg_description, 'urdf', 'rover.urdf.xacro')).toxml()
    arm_xml = xacro.process_file(os.path.join(pkg_description, 'urdf', 'manipulator.urdf.xacro')).toxml()

    # 2. Gazebo World
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([os.path.join(pkg_ros_gz_sim, 'launch', 'gz_sim.launch.py')]),
        launch_arguments={'gz_args': '-r empty.sdf'}.items(),
    )

    # 3. Spawn Rover (Set Z to 0.15 to avoid ground collision)
    spawn_rover = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=['-string', rover_xml, '-name', 'my_rover', '-x', '0.0', '-y', '-2.0', '-z', '0.1'],
        output='screen'
    )

    # 4. Spawn Arm
    spawn_arm = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=['-string', arm_xml, '-name', 'manipulator', '-x', '-0.45', '-y', '0.0', '-z', '0.1'],
        output='screen'
    )

    # 5. The Communication Bridge
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            # --- ROVER ---
            '/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
            '/model/my_rover/odometry@nav_msgs/msg/Odometry@gz.msgs.Odometry',
            
            # --- ARM COMMANDS ---
            '/model/manipulator/joint/joint_1/cmd_pos@std_msgs/msg/Float64]gz.msgs.Double',
            '/model/manipulator/joint/joint_2/cmd_pos@std_msgs/msg/Float64]gz.msgs.Double',
            
            # --- SHARED/SENSORS ---
            '/joint_states@sensor_msgs/msg/JointState[gz.msgs.ModelContact',
            '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock]',
            '/arm/scan@sensor_msgs/msg/LaserScan[gz.msgs.LaserScan'
        ],
        remappings=[
            ('/model/my_rover/odometry', '/odom'),
            # No remapping needed for /arm/scan if URDF is fixed
        ],
        output='screen'
    )

    return LaunchDescription([
        gazebo,
        spawn_rover,
        spawn_arm,
        bridge
    ])